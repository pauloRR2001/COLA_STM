/* Copyright 2022-2025 Thales Alenia Space
 * Licensed to CS GROUP (CS) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * CS licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.orekit.gnss;


/** Observation Types for GNSS measurements.
 * @author Luc Maisonobe
 * @since 13.0
 */
public interface ObservationType {

    /** Get the name of the observation type.
     * @return name of the observation type
     */
    String getName();

    /** Get the measurement type.
     * @return measurement type
     */
    MeasurementType getMeasurementType();

    /** Get the signal code.
     * @return signal code
     */
    SignalCode getSignalCode();

    /** Get the signal for a specified satellite system.
     * @param system satellite system
     * @return signal for the satellite system, or null if satellite system not compatible
     */
    GnssSignal getSignal(SatelliteSystem system);

}
